 font - The Wild Breath of Zelda
http://www.dafont.com/the-wild-breath-of-zelda.font